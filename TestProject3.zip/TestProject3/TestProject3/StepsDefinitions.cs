using System;
using System.ComponentModel;
using Newtonsoft.Json.Linq;
using RestSharp;
using TechTalk.SpecFlow;

namespace TestProject3
{
    [Binding]
    public class StepsDefinitions
    {
        private const string BaseUrl = "https://restful-booker.herokuapp.com";
        private RestClient client;
        public RestResponse CreateResponse;
        public JObject CreateJsonResponse;
        private RestResponse UpdateResponse;
        private RestResponse DeleteResponse;
        public int CreatedId;

        private string GetBasicAuthHeader(string username, string password)
        {
            var authString = $"{username}:{password}";
            var authBase64 = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(authString));
            return $"Basic {authBase64}";
        }

        RestResponse CreateBooking(string fn, string ln, int tp, bool dp, string ci, string co, string an)
        {
            var bookingData = new
            {
                firstname = fn,
                lastname = ln,
                totalprice = tp,
                depositpaid = dp,
                bookingdates = new
                {
                    checkin = ci,
                    checkout = co
                },
                additionalneeds = an
            };

            var request = new RestRequest("/booking", Method.Post);
            request.AddHeader("Accept", "application/json");
            request.AddJsonBody(bookingData);
            var response = client.Execute(request);
            return response;
        }

        RestResponse ReadBooking(int id)
        {
            var request = new RestRequest("/booking/" + id, Method.Get);
            request.AddHeader("Accept", "application/json");
            var response = client.Execute(request);
            return response;
        }

        RestResponse UpdateBooking(int id, string fn, string ln, int tp, bool dp, string ci, string co, string an)
        {
            var bookingData = new
            {
                firstname = fn,
                lastname = ln,
                totalprice = tp,
                depositpaid = dp,
                bookingdates = new
                {
                    checkin = ci,
                    checkout = co
                },
                additionalneeds = an
            };

            var request = new RestRequest($"/booking/{id}", Method.Put);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Authorization", GetBasicAuthHeader("admin", "password123"));
            request.AddJsonBody(bookingData);
            var response = client.Execute(request);
            return response;
        }

        RestResponse DeleteBooking(int id)
        {
            var request = new RestRequest("/booking/" + id, Method.Delete);
            request.AddHeader("Accept", "application/json");
            request.AddHeader("Authorization", GetBasicAuthHeader("admin", "password123"));
            var response = client.Execute(request);
            return response;

        }

        [Given(@"I have the API base URL ""http://restful-booker.herokuapp.com""")]
        public void CreateRestClient()
        {
            client = new RestClient(BaseUrl);
        }

        [When(@"I create a booking with valid details")]
        public void TestCreate()
        {
            CreateResponse = CreateBooking("Bill", "Black", 500, true, "2024-11-25", "2024-11-30", "Nothing");
        }

        [Then(@"the booking is created successfully")]
        public void CheckStatusCode()
        {
            Assert.AreEqual(200, (int)CreateResponse.StatusCode, "Status code is not 200 OK");
            Console.WriteLine(CreateResponse.Content);
        }

        [Then(@"I store the booking ID")]
        public void CheckBookingId()
        {
            CreateJsonResponse = JObject.Parse(CreateResponse.Content);
            CreatedId = Int32.Parse(CreateJsonResponse.GetValue("bookingid").ToString());
            Assert.IsNotNull(CreatedId);
        }

        [Then(@"response contain booking with details I entered")]
        public void CheckBookingInfo()
        {
            var ReadResponse = ReadBooking(CreatedId);
            Console.WriteLine(ReadResponse.Content);
            var jsonRead = JObject.Parse(ReadResponse.Content);
        }

        


        [When(@"I update the booking with new details")]
        public void UpdateTheBooking()
        {
            UpdateResponse = UpdateBooking(CreatedId, "Regina", "Ghallager", 200, true, "2024-12-28", "2025-01-01", "Nothing");
        }

        [Then(@"the booking is updated successfully")]
        public void UpdateCheckStatusCode()
        {
            Assert.AreEqual(200, (int)UpdateResponse.StatusCode, "Status code is not 200 OK");
            Console.WriteLine(UpdateResponse.Content);
        }

        [Then(@"response contain new details")]
        public void CheckUpdatedBookingInfo()
        {
            var ReadResponse = ReadBooking(CreatedId);
            Console.WriteLine(ReadResponse.Content);
            var jsonRead = JObject.Parse(ReadResponse.Content);
        }

        [When(@"I delete the booking using the booking ID")]
        public void DeleteTheBooking()
        {
            DeleteResponse = DeleteBooking(CreatedId);
            Console.WriteLine(DeleteResponse.Content);

        }

        [Then(@"the booking is deleted successfully")]
        public void DeleteCheckStatusCode()
        {
            Assert.AreEqual(201, (int)DeleteResponse.StatusCode, "Status code is not 201 OK");
            Console.WriteLine(DeleteResponse.Content);
        }

        [Then(@"response details is empty")]
        public void CheckDeletedBookingInfo()
        {
            var ReadResponse = ReadBooking(CreatedId);
            Console.WriteLine(ReadResponse.Content);
            Assert.IsTrue(string.IsNullOrEmpty(ReadResponse.Content) || ReadResponse.Content.Contains("Not Found"), "Response content is not empty or does not indicate 'Not Found'.");
            Assert.AreEqual(404, (int)ReadResponse.StatusCode, "Status code is not 404 Not Found");

        }
    }
}