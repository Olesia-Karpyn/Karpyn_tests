using RestSharp;
using Newtonsoft.Json.Linq;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OnThisDayApiTests
{
    [Binding]
    public class OnThisDayApiSteps
    {
        private RestClient _client;
        private RestResponse _response;

        public OnThisDayApiSteps()
        {
            _client = new RestClient("https://byabbe.se/on-this-day/");
        }

        [Given(@"I send a GET request to ""(.*)""")]
        public void GivenISendAGETRequestTo(string endpoint)
        {
            var request = new RestRequest(endpoint, Method.Get);
            _response = _client.Execute(request);

            Assert.IsNotNull(_response, "Response is null.");
        }

        [Then(@"the response should be valid JSON")]
        public void ThenTheResponseShouldBeValidJSON()
        {
            Assert.AreEqual(200, (int)_response.StatusCode, $"Expected 200 OK but got {(int)_response.StatusCode} {_response.StatusDescription}");
            Assert.AreEqual("application/json", _response.ContentType.Split(';')[0], "Expected content type application/json.");

            bool isValidJson = IsValidJson(_response.Content);
            Assert.IsTrue(isValidJson, "Response is not valid JSON.");
        }

        [Then(@"the response should contain events data")]
        public void ThenTheResponseShouldContainEventsData()
        {
            Assert.IsTrue(_response.Content.Contains("events"), "Response does not contain events data.");
        }

        [Then(@"the response should contain birth data")]
        public void ThenTheResponseShouldContainBirthData()
        {
            Assert.IsTrue(_response.Content.Contains("births"), "Response does not contain birth data.");
        }

        [Then(@"the response should contain death data")]
        public void ThenTheResponseShouldContainDeathData()
        {
            Assert.IsTrue(_response.Content.Contains("deaths"), "Response does not contain death data.");
        }

        private bool IsValidJson(string jsonString)
        {
            try
            {
                JToken.Parse(jsonString);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}