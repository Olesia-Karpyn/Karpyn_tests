﻿using AnalaizerClassLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProject2
{
    [TestClass]
    public class UnaryPlusMinusTests
    {
        private const char SYMBOL_UNARY_PLUS = 'p';  // Позначення унарного плюса
        private const char SYMBOL_UNARY_MINUS = 'm'; // Позначення унарного мінуса

        public TestContext TestContext { get; set; }

        [TestMethod]
        [DataSource("System.Data.SqlClient", @"Data Source=.\SqlExpress01;Initial Catalog=DBTests;Integrated Security=True;Pooling=False", "UnaryTestData", DataAccessMethod.Sequential)]
        public void ReplaceUnaryOperator_FromDB()
        {
            string input = (string)TestContext.DataRow["Input"];
            string expected = (string)TestContext.DataRow["Expected"];
            string result = AnalaizerClass.ReplaceUnaryPlusMinus(input);

            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void ReplaceUnaryPlus_WhenAtBeginning_ShouldInsertUnaryPlus()
        {
            string input = "+5+3";
            string expected = "p5+3"; // Унарний плюс перед 5
            string result = AnalaizerClass.ReplaceUnaryPlusMinus(input);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void ReplaceUnaryMinus_WhenAtBeginning_ShouldInsertUnaryMinus()
        {
            string input = "-5+3";
            string expected = "m5+3"; // Унарний мінус перед 5
            string result = AnalaizerClass.ReplaceUnaryPlusMinus(input);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void ReplaceUnaryMinus_AfterOperator_ShouldInsertUnaryMinus()
        {
            string input = "3*-2";
            string expected = "3*m2"; // Унарний мінус після оператора *
            string result = AnalaizerClass.ReplaceUnaryPlusMinus(input);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void ReplaceUnaryPlus_AfterBracket_ShouldInsertUnaryPlus()
        {
            string input = "(+5+2)*3";
            string expected = "(p5+2)*3"; // Унарний плюс після відкриваючої дужки
            string result = AnalaizerClass.ReplaceUnaryPlusMinus(input);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void NoChangeForBinaryOperators_ShouldRemainSame()
        {
            string input = "3+5-2";
            string expected = "3+5-2"; // Бінарні оператори не змінюються
            string result = AnalaizerClass.ReplaceUnaryPlusMinus(input);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void MultipleUnaryOperators_ShouldInsertCorrectly()
        {
            string input = "-(+3)+5";
            string expected = "m(p3)+5"; // Унарний плюс і мінус вставлені правильно
            string result = AnalaizerClass.ReplaceUnaryPlusMinus(input);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void ReplaceUnaryMinus_WhenAtEnd_ShouldRemainSame()
        {
            string input = "5-";
            string expected = "5-"; // Останній мінус не унарний
            string result = AnalaizerClass.ReplaceUnaryPlusMinus(input);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void OnlyUnaryMinus_ShouldInsertUnaryMinus()
        {
            string input = "-5";
            string expected = "m5"; // Унарний мінус перед 5
            string result = AnalaizerClass.ReplaceUnaryPlusMinus(input);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void InvalidExpression_ShouldHandleGracefully()
        {
            string input = "+";
            string expected = "+"; // Унарний плюс без операндів
            string result = AnalaizerClass.ReplaceUnaryPlusMinus(input);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void ReplaceUnaryPlus_BeforeBracket_ShouldInsertUnaryPlus()
        {
            string input = "+(5-3)";
            string expected = "p(5-3)"; // Унарний плюс перед відкриваючою дужкою
            string result = AnalaizerClass.ReplaceUnaryPlusMinus(input);
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void ReplaceUnaryMinus_BeforeBracket_ShouldInsertUnaryMinus()
        {
            string input = "-(5+3)";
            string expected = "m(5+3)"; // Унарний мінус перед відкриваючою дужкою
            string result = AnalaizerClass.ReplaceUnaryPlusMinus(input);
            Assert.AreEqual(expected, result);
        }

    }
}
