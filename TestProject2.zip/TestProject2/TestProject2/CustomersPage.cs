﻿using OpenQA.Selenium;

namespace TestProject2.Pages
{
    public class CustomersPage
    {
        private readonly IWebDriver _driver;

        public CustomersPage(IWebDriver driver)
        {
            _driver = driver;
        }

        private readonly By customersButton = By.XPath("//button[normalize-space(text())='Customers']");
        private readonly By postCodeColumn = By.XPath("//th[normalize-space(text())='Post Code']");
        private readonly By customerTable = By.CssSelector("table tbody");

        public void ClickCustomersButton()
        {
            var customersButtonElement = _driver.FindElement(customersButton);
            customersButtonElement.Click();
        }

        public void ClickSortPostCode()
        {
            var postCodeColumnElement = _driver.FindElement(postCodeColumn);
            postCodeColumnElement.Click();
        }

        public bool IsCustomerListVisible()
        {
            return _driver.FindElement(customerTable).Displayed;
        }

        public bool VerifySortingByPostCode()
        {
            var rows = _driver.FindElements(By.CssSelector("table tbody tr")).Select(row =>
            {
                var columns = row.FindElements(By.TagName("td")).ToList();
                return columns.Count > 0 ? columns[3].Text : string.Empty;
            }).ToList();

            var isSortedAscending = rows.SequenceEqual(rows.OrderBy(x => x));
            var isSortedDescending = rows.SequenceEqual(rows.OrderByDescending(x => x));

            return isSortedAscending || isSortedDescending;
        }
    }
}
