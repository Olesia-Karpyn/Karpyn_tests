﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using TechTalk.SpecFlow;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumExtras.WaitHelpers;
using System;
using System.Linq;
using TestProject2.Drivers;

namespace TestProject2
{
    [Binding]
    public class SortPostCodeSteps
    {
        private readonly IWebDriver _driver;
        private readonly BrowserDriver _browserDriver;

        public SortPostCodeSteps(BrowserDriver browserDriver)
        {
            _browserDriver = browserDriver;
            _driver = _browserDriver.GetDriver();
        }

        [Given(@"I open XYZ Bank website")]
        public void GivenIOpenXYZBankWebsite()
        {
            var url = "https://www.globalsqa.com/angularJs-protractor/BankingProject";
            _driver.Navigate().GoToUrl(url);

            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(30));
            var loginButton = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("//button[contains(text(), 'Bank Manager')]")));
            Assert.IsTrue(loginButton.Displayed, "Сторінка не завантажилася, або кнопка 'Bank Manager' недоступна.");
        }

        [When(@"I login as Bank Manager")]
        public void WhenILoginAsBankManager()
        {
            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(30));
            var loginButton = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("//button[contains(text(), 'Bank Manager')]")));
            ((IJavaScriptExecutor)_driver).ExecuteScript("arguments[0].click();", loginButton);
        }

        [When(@"I see the customers page")]
        public void WhenISeeTheCustomersPage()
        {
            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.UrlContains("/manager"));
            Assert.IsTrue(_driver.Url.Contains("/manager"), "Користувач не потрапив на сторінку 'Manager'.");
        }

        [When(@"I click on Customers Button")]
        public void WhenIClickOnCustomersButton()
        {
            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(20));
            var customersButton = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("//button[normalize-space(text())='Customers']")));
            customersButton.Click();
        }

        [When(@"I see list of customers")]
        public void WhenISeeListOfCustomers()
        {
            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(20));
            var customerTable = wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector("table tbody")));
            Assert.IsTrue(customerTable.Displayed, "Список клієнтів недоступний.");
        }

        [When(@"I click on Post Code")]
        public void WhenIClickOnPostCode()
        {
            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(40));

            try
            {
                // Очікуємо, що таблиця стане доступною
                var tableBody = wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector("table tbody")));
                Assert.IsTrue(tableBody.Displayed, "Таблиця з клієнтами не завантажилась.");

                // Шукаємо елемент з текстом 'Post Code'
                var postCodeElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.LinkText("Post Code")));

                Assert.IsTrue(postCodeElement.Displayed, "Елемент 'Post Code' не видно для кліку.");

                postCodeElement.Click();
                Console.WriteLine("Перший клік: Сортування по спаданням");

                wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector("table tbody tr")));
                Thread.Sleep(1000);

                // Перевірка сортування після першого кліку
                var postCodes = GetPostCodesFromTable();
                var sortedPostCodesDesc = postCodes.OrderByDescending(x => x).ToList();
                Assert.IsTrue(postCodes.SequenceEqual(sortedPostCodesDesc), "Поштові коди не відсортовані за спаданням.");
                Console.WriteLine("Поштові коди відсортовані за спаданням.");

                postCodeElement.Click();
                Thread.Sleep(1000); 

                postCodes.Clear();
                postCodes.AddRange(GetPostCodesFromTable());
                var sortedPostCodesAsc = postCodes.OrderBy(x => x).ToList();
                Assert.IsTrue(postCodes.SequenceEqual(sortedPostCodesAsc), "Поштові коди не відсортовані за зростанням.");
                Console.WriteLine("Поштові коди відсортовані за зростанням.");
            }
            catch (WebDriverTimeoutException ex)
            {
                Assert.Fail($"Тайм-аут при очікуванні елемента 'Post Code': {ex.Message}");
            }
            catch (NoSuchElementException ex)
            {
                Assert.Fail($"Елемент 'Post Code' не знайдений: {ex.Message}");
            }
            catch (Exception ex)
            {
                Assert.Fail($"Неочікувана помилка: {ex.Message}");
            }
        }

        private List<string> GetPostCodesFromTable()
        {
            var postCodes = new List<string>();
            var customerRows = _driver.FindElements(By.CssSelector("table tbody tr"));

            foreach (var row in customerRows)
            {
                try { 
                
                    var postCodeCell = row.FindElement(By.XPath(".//td[contains(text(), 'E')]"));
                    postCodes.Add(postCodeCell.Text.Trim());
                }
                catch (NoSuchElementException)
                {
                    Console.WriteLine("Поштовий код не знайдений в рядку.");
                }
            }

            return postCodes;
        }

        private bool isDescending = false; 

        [Then(@"the customers should be sorted by Post Code")]
        public void ThenTheCustomersShouldBeSortedByPostCode()
        {
            var wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(10));

            wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector("table tbody tr")));

            var customerRows = _driver.FindElements(By.CssSelector("table tbody tr"));
            var postCodes = new List<string>();

            foreach (var row in customerRows)
            {
                try
                {
                    // Шукаємо клітинку з поштовим кодом
                    var postCodeCell = row.FindElement(By.XPath(".//td[contains(text(), 'E')]"));

                    // Додаємо текст поштового коду до списку
                    postCodes.Add(postCodeCell.Text.Trim());
                }
                catch (NoSuchElementException)
                {
                    // Логуємо відсутність елемента, якщо не знайдено
                    Console.WriteLine("Поштовий код не знайдений в рядку.");
                }
            }

            // Перевіряємо, чи сортування було здійснено по спаданню або зростанню
            if (isDescending)
            {
                // Якщо було сортування по спаданню, перевіряємо, чи відсортовані поштові коди в порядку спадання
                var sortedPostCodesDesc = postCodes.OrderByDescending(x => x).ToList();
                Assert.IsTrue(postCodes.SequenceEqual(sortedPostCodesDesc), "Список клієнтів не відсортовано за поштовим кодом в порядку спадання.");
                Console.WriteLine("Поштові коди відсортовані за спаданням.");
            }
            else
            {
                // Якщо було сортування по зростанню, перевіряємо, чи відсортовані поштові коди в порядку зростання
                var sortedPostCodesAsc = postCodes.OrderBy(x => x).ToList();
                Assert.IsTrue(postCodes.SequenceEqual(sortedPostCodesAsc), "Список клієнтів не відсортовано за поштовим кодом в порядку зростання.");
                Console.WriteLine("Поштові коди відсортовані за зростанням.");
            }

            isDescending = !isDescending;
        }
    }
}