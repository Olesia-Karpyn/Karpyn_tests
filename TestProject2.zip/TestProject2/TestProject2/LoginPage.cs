﻿using OpenQA.Selenium;

namespace TestsLab2.Pages
{
    public class LoginPage
    {
        private readonly IWebDriver _driver;

        public LoginPage(IWebDriver driver)
        {
            _driver = driver;
        }

        private readonly By bankManagerLoginButton = By.XPath("//button[contains(text(), 'Bank Manager')]");

        public void ClickBankManagerLogin()
        {
            var loginButton = _driver.FindElement(bankManagerLoginButton);
            loginButton.Click();
        }
    }
}
