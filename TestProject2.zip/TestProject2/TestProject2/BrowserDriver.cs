﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace TestProject2.Drivers
{
    public class BrowserDriver
    {
        private IWebDriver _driver;

        public IWebDriver GetDriver()
        {
            if (_driver == null)
            {
                _driver = new ChromeDriver(); // Ініціалізація ChromeDriver
            }
            return _driver;
        }

        public void CloseDriver()
        {
            _driver?.Quit();
        }
    }
}
